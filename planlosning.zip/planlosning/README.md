# Planlösning – Installationsguide

## Vad är detta?
En webbapp för att rita planlösningar, byggd med React + PWA-stöd.
Den kan installeras som en riktig app på iPhone, iPad och Android.

---

## Alternativ 1 – Netlify Drop (enklast, 2 minuter)

1. Gå till https://app.netlify.com/drop i din webbläsare
2. Bygg projektet först (se "Bygga projektet" nedan)
3. Dra och släpp mappen `dist/` till Netlify Drop
4. Du får en länk, t.ex. `https://random-name.netlify.app`
5. Öppna länken i Safari (iPhone/iPad) eller Chrome (Android)
6. Installera som app – se nedan

---

## Alternativ 2 – Vercel (också enkelt)

1. Skapa konto på https://vercel.com
2. Installera Vercel CLI: `npm i -g vercel`
3. Kör i projektmappen: `vercel --prod`
4. Följ instruktionerna – du får en länk direkt

---

## Bygga projektet

```bash
# 1. Installera beroenden
npm install

# 2. Bygg för produktion
npm run build

# 3. Testa lokalt (valfritt)
npm run preview
```

Byggda filer hamnar i `dist/` – det är den mappen du laddar upp.

---

## Installera som app på mobil

### iPhone / iPad (Safari)
1. Öppna din publicerade länk i **Safari**
2. Tryck på **dela-ikonen** (rutan med pil uppåt) i menyraden
3. Scrolla ner och tryck **"Lägg till på hemskärmen"**
4. Tryck **Lägg till** – appen dyker upp som en ikon!

> ⚠️ Måste göras i Safari, fungerar inte i Chrome på iPhone.

### Android (Chrome)
1. Öppna länken i **Chrome**
2. Tryck på **⋮** (tre punkter) uppe till höger
3. Tryck **"Lägg till på startskärmen"** eller **"Installera app"**
4. Bekräfta – appen installeras!

---

## Köra lokalt under utveckling

```bash
npm install
npm run dev
```

Öppna http://localhost:5173 i webbläsaren.

---

## Projektstruktur

```
planlosning/
├── public/
│   ├── icon-192.png        # App-ikon (liten)
│   ├── icon-512.png        # App-ikon (stor)
│   └── icon-maskable.png   # Android maskable ikon
├── src/
│   ├── main.jsx            # React entry point
│   └── App.jsx             # Hela appen
├── index.html              # HTML-mall
├── vite.config.js          # Vite + PWA-konfiguration
└── package.json            # Beroenden
```
